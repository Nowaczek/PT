﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Net.Sockets;
using System.Net;
using System.IO;
using Activity_Monitor_Client;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace ZdalnyScreenshotKlient
{
    public partial class Klient : Form
    {
        private int serwerKomendPort = 1978;
        private IPAddress serwerDanychIP;
        private int serwerDanychPort;
        private string adresLokalnyIP;
        private Bitmap obraz;
        private Processes procesy;

        Size nowyrozmiar = new Size(800, 450);
        przegladarki przegladarka = new przegladarki();

        public Klient()
        {
            InitializeComponent();

           
            
            IPHostEntry adresIP = Dns.GetHostEntry(Dns.GetHostName());
             foreach(var s in  adresIP.AddressList){
                 string[] parts = s.ToString().Split('.');
                 if (parts.Length == 4)
                 {
                     comboBox1.Items.Add(s.ToString());
                 }   
            }
             comboBox1.Items.Add("127.0.0.1");

           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //WyslijWiadomoscUDP(adresLokalnyIP + ":HI");
        }

        private Bitmap wykonajScreenshot()
        {
            Bitmap bitmapa = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format32bppArgb);
            Graphics screenshot = Graphics.FromImage(bitmapa);
            screenshot.CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size, CopyPixelOperation.SourceCopy);
            bitmapa = zmien(bitmapa, nowyrozmiar);
            return bitmapa;
        }

        delegate void SetTextCallBack(string tekst);
        private void SetText(string tekst)
        {
            if (listBox1.InvokeRequired)
            {
                SetTextCallBack f = new SetTextCallBack(SetText);
                this.Invoke(f, new object[] { tekst });
            }
            else
            {
                this.listBox1.Items.Add(tekst);
            }
        }

        static string czyscbialeznaki(string text) { return Regex.Replace(text.Trim(), @"\nul+", ""); }

        public Bitmap zmien(Bitmap imgToResize, Size size)
        {
            Bitmap bitmap = new Bitmap(size.Width, size.Height);
            using (Graphics graphics = Graphics.FromImage((Image)bitmap))
            {
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.DrawImage(imgToResize, 0, 0, size.Width, size.Height);
            }
            return bitmap;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            TcpListener serwer = new TcpListener(IPAddress.Parse(adresLokalnyIP), serwerKomendPort);
            serwer.Start();
            this.SetText("Oczekuje na komendy...");
            while (true)
            {
                try
                {
                TcpClient klientKomend = serwer.AcceptTcpClient();
                //this.SetText("Otrzymano komende.");
                NetworkStream ns = klientKomend.GetStream();
                Byte[] bufor = new Byte[100];
                int odczyt = ns.Read(bufor, 0, bufor.Length);
                String s = Encoding.ASCII.GetString(bufor);
                string wiadomosc = Encoding.ASCII.GetString(bufor);
                if (wiadomosc.Contains("##S##"))
                {
                    //this.SetText("Zrzut ekranu w trakcie wykonywania ...");
                    obraz = wykonajScreenshot();
                    MemoryStream ms = new MemoryStream();
                    obraz.Save(ms, ImageFormat.Jpeg);
                    byte[] obrazByte = ms.GetBuffer();
                    ms.Close();
                    try
                    {
                        TcpClient klient2 = new TcpClient(serwerDanychIP.ToString(), serwerDanychPort);//
                        NetworkStream ns2 = klient2.GetStream();
                        //this.SetText("Wysyłanie zrzutu ...");
                        using (BinaryWriter bw = new BinaryWriter(ns2))
                        {
                            bw.Write((int)obrazByte.Length);
                            bw.Write(obrazByte);
                        }
                        //this.SetText("Zrzut ekranu przesłany");
                    }
                    catch (Exception ex)
                    {
                        this.SetText("Nie można połączyć z serwerem");
                    }
                }
                if (wiadomosc.Contains("##P##"))
                {
                    string[] proc = Processes.getProcesses();
                    string wiadomoscudp = String.Empty;
                    foreach (string p in proc)
                    {
                        wiadomoscudp += p + ";"; 
                    }
                    WyslijWiadomoscUDP(adresLokalnyIP + ":PROC:" + wiadomoscudp);
                }
                if (wiadomosc.Contains("##PB##"))
                {
                    string name = wiadomosc + "#";
                    name = wyciagnij(name, "##PB##", "##END##");
                    
                    foreach (var process in Process.GetProcessesByName(name))
                    {
                        process.Kill();
                    }
                }
                }
                catch {}
            }
        }

        public string wyciagnij(string source, string poczatek, string koniec)
        {
            try
            {
                string x;

                int indexpoczatek = (source.IndexOf(poczatek)) + poczatek.Length;
                x = source.Substring(indexpoczatek, source.Length - indexpoczatek);

                int indexkoniec = x.IndexOf(koniec);

                x = x.Substring(0, indexkoniec);

                return x;
            }
            catch
            {
                return "0";
            }
        }


        private void WyslijWiadomoscUDP(string wiadomosc)
        {
            UdpClient klient = new UdpClient(serwerDanychIP.ToString(), 43210);
            byte[] bufor = Encoding.ASCII.GetBytes(wiadomosc);
            klient.Send(bufor, bufor.Length);
            klient.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                WyslijWiadomoscUDP(adresLokalnyIP + ":BYE");
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string [] proc = Processes.getProcesses();
            foreach (string proces in proc)
            {
                listBox2.Items.Add(proces);
            }
            //WyslijWiadomoscUDP(adresLokalnyIP + ":STRING:" + tb_wiadomosc.Text);
        }

        private void b_loguj_Click(object sender, EventArgs e)
        {
            adresLokalnyIP = comboBox1.SelectedItem.ToString();
            serwerDanychIP = IPAddress.Parse(tb_adresIPserwer.Text);
            serwerDanychPort = Convert.ToInt32(tb_port.Text);

            WyslijWiadomoscUDP(adresLokalnyIP + ":LOGIN:" + tb_imie.Text + ":" + tb_nazwisko.Text + ":" + tb_index.Text);
            
            notifyIcon1.Visible = true;
            notifyIcon1.Text = "Program Minimalizujący";
            notifyIcon1.Icon = this.Icon;
            notifyIcon1.ContextMenuStrip = contextMenuStrip1;
            this.ShowInTaskbar = false;
            this.Visible = false;
            
            timer1.Start(); // wysyla strony www
            backgroundWorker1.RunWorkerAsync(); // oczekuje na komunikaty
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            WyslijWiadomoscUDP(adresLokalnyIP + ":URL:" + przegladarka.GetBrowserFirefox());
        }

        private readonly Random getrandom = new Random();
        private readonly object syncLock = new object();

        public int GetRandomNumber(int min, int max)
        {
            lock (syncLock)
            { // synchronize
                return getrandom.Next(min, max);
            }
        }

        public void delay(int sekundy1, int sekundy2)
        {
            int sekundy = GetRandomNumber(sekundy1, sekundy2);

            for (int i = 0; i < sekundy * 2000000; i++)
            {
                Application.DoEvents(); // rekakcja na guzik
            }
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WyslijWiadomoscUDP(adresLokalnyIP + ":BYE");
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

    }
}
