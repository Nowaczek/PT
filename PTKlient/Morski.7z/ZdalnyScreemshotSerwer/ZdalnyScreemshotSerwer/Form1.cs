﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;

namespace ZdalnyScreemshotSerwer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //backgroundWorker1.RunWorkerAsync();
            backgroundWorker2.RunWorkerAsync();

            IPHostEntry adresIP = Dns.GetHostEntry(Dns.GetHostName());
           tbIPServera.Text = adresIP.AddressList[1].ToString();
        }

        List<string> listurl = new List<string>();
        public string adresIPblock;
        public bool podgladStrona = false;
        List<string> listaStringow = new List<string>();

        delegate void SetTextCallBack(string tekst);
        private void SetText(string tekst)
        {
            if (listBoxKlienci.InvokeRequired)
            {
                SetTextCallBack f = new SetTextCallBack(SetText);
                this.Invoke(f, new object[] { tekst });
            }
            else
            {
                this.listBoxKlienci.Items.Add(tekst);
            }
        }

        delegate void RemoveTextCallBack(int pozycja);

        private void RemoveText(int pozycja)
        {
            if (listBoxKlienci.InvokeRequired)
            {
                RemoveTextCallBack f = new RemoveTextCallBack(RemoveText);
                this.Invoke(f, new object[] { pozycja });
            }
            else
            {
                listBoxKlienci.Items.RemoveAt(pozycja);
            }
        }

        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            IPEndPoint zdalnyIP = new IPEndPoint(IPAddress.Any, 0);
            UdpClient klient = new UdpClient(43210);
            while (true)
            {
                Byte[] bufor = klient.Receive(ref zdalnyIP);
                string dane = Encoding.ASCII.GetString(bufor);
                string[] cmd = dane.Split(new char[] { ':' });

                //MessageBox.Show(cmd[1]);
                
                if (cmd[1] == "HI")
                {
                    foreach(string wpis in listBoxKlienci.Items)
                        if (wpis == cmd[0])
                        {
                            MessageBox.Show("Proba nawiazania polaczenie z " + cmd[0] + " odrzucona poniewaz na liscie istnieje juz taki wpis");
                            return;
                        }
                    this.SetText(cmd[0]);
                }
                if (cmd[1] == "BYE")
                {
                    for (int i = 0; i < listBoxKlienci.Items.Count; i++)
                        if (listBoxKlienci.Items[i].ToString() == cmd[0])
                            this.RemoveText(i);

                    foreach (user u in listuser)
                    {
                        if (u.adres == cmd[0])
                        {
                            for (int i = 0; i < listBoxKlienci.Items.Count; i++)
                                if (listBoxKlienci.Items[i].ToString() == u.imienazwisko)
                                    this.RemoveText(i);
                        }
                    }
                        
                }
                if (cmd[1] == "LOGIN")
                {
                    foreach (user u in listuser)
                    {
                        if (cmd[2] == u.index && cmd[3] == u.haslo)
                        {
                            for (int i = 0; i < listBoxKlienci.Items.Count; i++)
                                if (listBoxKlienci.Items[i].ToString() == cmd[0])
                                    this.RemoveText(i);

                            this.SetText(u.imienazwisko);
                            u.adresIP(cmd[0]); // aktualny adres IP
                            //autoryzacja(cmd[0]);
                        }
                    }
                }
                if (cmd[1] == "STRING")
                {
                    MessageBox.Show("wiadomość od - " + cmd[0] + " - " + cmd[2]);
                }

                if (cmd[1] == "PROC")
                {
                    MessageBox.Show("wiadomość od - " + cmd[0] + " - " + cmd[2]);
                    string[] tablica = cmd[2].Split(';');
                    
                    foreach (string proces in tablica)
                    {
                        listaStringow.Add(proces);
                    }
                }

                if (cmd[1] == "URL" && !podgladStrona)
                {
                    try{
                    //MessageBox.Show("wiadomość od - " + cmd[0] + " - " + cmd[2] + cmd[3]);
                    string url = cmd[2] + cmd[3];
                    string name = String.Empty;

                    foreach (string u in listurl)
                    {
                        if (url.Contains(u))
                        {
                            foreach (user osoba in listuser)
                            {
                                if (osoba.adres == cmd[0])
                                    name = osoba.imienazwisko;
                                else
                                    name = cmd[0];
                            }

                            DialogResult result1 = MessageBox.Show("Użytkownik - " + name + " korzysta z niedozwolonej strony, chcesz sprawdzić co robi?",
                            "Uwaga",
                            MessageBoxButtons.YesNo);

                            if (result1 == DialogResult.Yes)
                            {
                                adresIPblock = cmd[0];
                                timer2.Start();
                            }
                            else
                            {
                                //
                            }
                           
                        }
                    }
                }catch{}//
                }
                

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            //print();
            //timer2.Start();
        }

        private void print()
        {
            /*
            if (listBox1.SelectedIndex == -1)
                return;*/
            try
            {
                string adresIP = String.Empty;
                if (listBoxKlienci.Items[listBoxKlienci.SelectedIndex].ToString().Contains("."))
                    adresIP = listBoxKlienci.Items[listBoxKlienci.SelectedIndex].ToString();
                else
                {
                    foreach (user u in listuser)
                    {
                        if (u.imienazwisko == listBoxKlienci.Items[listBoxKlienci.SelectedIndex].ToString())
                            adresIP = u.adres;
                    }
                }
                TcpClient klient = new TcpClient(adresIP, 1978);
                NetworkStream ns = klient.GetStream();
                byte[] bufor = new byte[5];
               // MessageBox.Show("wysyla");
                bufor = Encoding.ASCII.GetBytes("##S##");
                ns.Write(bufor, 0, bufor.Length);
                if (backgroundWorker1.IsBusy == false)
                    backgroundWorker1.RunWorkerAsync();
                //else
                   // MessageBox.Show("Nie mozna teraz zrealizowac zrzutu ekranu");
            }
            catch
            {
                //MessageBox.Show("Blad: nie mozna nawiazac polaczenia.");
            }
        }

        private void proces()
        {
            /*
            if (listBox1.SelectedIndex == -1)
                return;*/
            try
            {
                string adresIP = String.Empty;
                if (listBoxKlienci.Items[listBoxKlienci.SelectedIndex].ToString().Contains("."))
                    adresIP = listBoxKlienci.Items[listBoxKlienci.SelectedIndex].ToString();
                else
                {
                    foreach (user u in listuser)
                    {
                        if (u.imienazwisko == listBoxKlienci.Items[listBoxKlienci.SelectedIndex].ToString())
                            adresIP = u.adres;
                    }
                }
                TcpClient klient = new TcpClient(adresIP, 1978);
                NetworkStream ns = klient.GetStream();
                byte[] bufor = new byte[5];
                // MessageBox.Show("wysyla");
                bufor = Encoding.ASCII.GetBytes("##P##");
                ns.Write(bufor, 0, bufor.Length);
                timer2.Start();
                //if (backgroundWorker1.IsBusy == false)
                   // backgroundWorker1.RunWorkerAsync();
                //else
                // MessageBox.Show("Nie mozna teraz zrealizowac zrzutu ekranu");
            }
            catch
            {
                //MessageBox.Show("Blad: nie mozna nawiazac polaczenia.");
            }
        }

        private void printBlock(string adresIP)
        {
            try
            {
            podgladStrona = true;
                TcpClient klient = new TcpClient(adresIP, 1978);
                NetworkStream ns = klient.GetStream();
                byte[] bufor = new byte[5];
                bufor = Encoding.ASCII.GetBytes("##S##");
                ns.Write(bufor, 0, bufor.Length);
                if (backgroundWorker1.IsBusy == false)
                    backgroundWorker1.RunWorkerAsync();
                /*else
                    MessageBox.Show("Nie mozna teraz zrealizowac zrzutu ekranu");*/
            }
            catch
            {
                //MessageBox.Show("Blad: nie mozna nawiazac polaczenia.");
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            TcpListener serwer2 = new TcpListener(IPAddress.Parse(tbIPServera.Text), (int)numericUpDown1.Value);
            serwer2.Start();
            TcpClient klient2 = serwer2.AcceptTcpClient();
            NetworkStream ns = klient2.GetStream();
            byte[] obrazByte;
            using(BinaryReader odczytObrazu = new BinaryReader(ns))
            {
                int rozmiarObrazu = odczytObrazu.ReadInt32();
                obrazByte = odczytObrazu.ReadBytes(rozmiarObrazu);
            }
            using (MemoryStream ms = new MemoryStream(obrazByte))
            {
                Image obraz = Image.FromStream(ms);
                pictureBox1.Image = obraz;
            }
            serwer2.Stop();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            user kamil = new user("Kamil Zieliński", "106046", "1", "1", "1", "kamil");
            user mikolaj = new user("Mikołaj Morski", "106052", "1", "1", "1", "mikolaj");
            user jakub = new user("Jakub Wasilewski", "106035", "1", "1", "1", "kuba");
            listuser.Add(kamil);
            listuser.Add(mikolaj);
            listuser.Add(jakub);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            print();
        }

        private void autoryzacja(string adresIP)
        {
            TcpClient klient = new TcpClient(adresIP, 1978);
            NetworkStream ns = klient.GetStream();
            byte[] bufor = new byte[5];
            bufor = Encoding.ASCII.GetBytes("##Y##");
            ns.Write(bufor, 0, bufor.Length);
            if (backgroundWorker1.IsBusy == false)
                backgroundWorker1.RunWorkerAsync();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        List<user> listuser = new List<user>();

        private void button3_Click(object sender, EventArgs e)
        {
            user nowy = new user(tb_imienazwisko.Text, tb_index.Text, tb_semestr.Text, tb_kierunek.Text, tb_grupa.Text, tb_haslo.Text);
            listuser.Add(nowy);
            MessageBox.Show("Użytkownik został dodany");
            // zrobic wyjatek jezyli uzytkownik juz jest // 
        }

        private void zapiszZrzutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string name = saveFileDialog1.FileName;
            pictureBox1.Image.Save(name, System.Drawing.Imaging.ImageFormat.Jpeg);
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (listaStringow.Count >0 )
            {
                listBoxProcesy.Items.Clear();
                foreach(string proces in listaStringow){
                    listBoxProcesy.Items.Add(proces);
                }
                listaStringow.Clear();
                timer2.Stop();
            }
            //printBlock(adresIPblock);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listurl.Add(tb_www.Text);
            MessageBox.Show("Strona została zablokowana");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            proces();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
