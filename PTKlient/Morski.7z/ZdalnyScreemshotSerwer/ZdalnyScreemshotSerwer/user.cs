﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZdalnyScreemshotSerwer
{
    class user
    {
        public string imienazwisko { get; set; }
        public string index { get; set; }
        public string grupa { get; set; }
        public string semestr { get; set; }
        public string kierunek { get; set; }
        public string haslo { get; set; }
        public string adres { get; set; }

        public user(string imienazwisko, string index, string semestr, string kierunek, string grupa, string haslo)
        {
            this.imienazwisko = imienazwisko;
            this.index = index;
            this.semestr = semestr;
            this.kierunek = kierunek;
            this.grupa = grupa;
            this.haslo = haslo;
        }

        public void adresIP(string adres)
        {
            this.adres = adres;
        }


    }
}
