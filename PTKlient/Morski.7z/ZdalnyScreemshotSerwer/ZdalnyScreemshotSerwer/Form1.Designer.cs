﻿namespace ZdalnyScreemshotSerwer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.listBoxKlienci = new System.Windows.Forms.ListBox();
            this.btnPodgladPulpitu = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.tbIPServera = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zapiszZrzutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.koniecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_haslo = new System.Windows.Forms.TextBox();
            this.btnDodajUzytkownika = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_semestr = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_kierunek = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_grupa = new System.Windows.Forms.TextBox();
            this.tb_index = new System.Windows.Forms.TextBox();
            this.tb_imienazwisko = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnBlokujURL = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_www = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.listBoxProcesy = new System.Windows.Forms.ListBox();
            this.btnWyswietlProcesy = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.pictureBox1.Location = new System.Drawing.Point(21, 22);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1060, 503);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnStop);
            this.groupBox1.Controls.Add(this.listBoxKlienci);
            this.groupBox1.Controls.Add(this.btnPodgladPulpitu);
            this.groupBox1.Location = new System.Drawing.Point(1145, 32);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(319, 309);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Klienci";
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(164, 271);
            this.btnStop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(145, 28);
            this.btnStop.TabIndex = 5;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // listBoxKlienci
            // 
            this.listBoxKlienci.FormattingEnabled = true;
            this.listBoxKlienci.ItemHeight = 16;
            this.listBoxKlienci.Location = new System.Drawing.Point(11, 21);
            this.listBoxKlienci.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBoxKlienci.Name = "listBoxKlienci";
            this.listBoxKlienci.Size = new System.Drawing.Size(297, 244);
            this.listBoxKlienci.TabIndex = 0;
            // 
            // btnPodgladPulpitu
            // 
            this.btnPodgladPulpitu.Location = new System.Drawing.Point(9, 271);
            this.btnPodgladPulpitu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPodgladPulpitu.Name = "btnPodgladPulpitu";
            this.btnPodgladPulpitu.Size = new System.Drawing.Size(145, 28);
            this.btnPodgladPulpitu.TabIndex = 4;
            this.btnPodgladPulpitu.Text = "Podglad pulpitu";
            this.btnPodgladPulpitu.UseVisualStyleBackColor = true;
            this.btnPodgladPulpitu.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.numericUpDown1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tbIPServera);
            this.groupBox2.Location = new System.Drawing.Point(1144, 729);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(319, 95);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Server";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(80, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "port";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(123, 57);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(187, 22);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "adres IP";
            // 
            // tbIPServera
            // 
            this.tbIPServera.Location = new System.Drawing.Point(124, 21);
            this.tbIPServera.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbIPServera.Name = "tbIPServera";
            this.tbIPServera.Size = new System.Drawing.Size(184, 22);
            this.tbIPServera.TabIndex = 0;
            this.tbIPServera.Text = "127.0.0.1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plikToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1674, 28);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plikToolStripMenuItem
            // 
            this.plikToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zapiszZrzutToolStripMenuItem,
            this.koniecToolStripMenuItem});
            this.plikToolStripMenuItem.Name = "plikToolStripMenuItem";
            this.plikToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.plikToolStripMenuItem.Text = "Plik";
            // 
            // zapiszZrzutToolStripMenuItem
            // 
            this.zapiszZrzutToolStripMenuItem.Name = "zapiszZrzutToolStripMenuItem";
            this.zapiszZrzutToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.zapiszZrzutToolStripMenuItem.Text = "Zapisz zrzut";
            this.zapiszZrzutToolStripMenuItem.Click += new System.EventHandler(this.zapiszZrzutToolStripMenuItem_Click);
            // 
            // koniecToolStripMenuItem
            // 
            this.koniecToolStripMenuItem.Name = "koniecToolStripMenuItem";
            this.koniecToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.koniecToolStripMenuItem.Text = "Koniec";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileName = "screen.jpg";
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker2_DoWork);
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.tb_haslo);
            this.groupBox3.Controls.Add(this.btnDodajUzytkownika);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.tb_semestr);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.tb_kierunek);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.tb_grupa);
            this.groupBox3.Controls.Add(this.tb_index);
            this.groupBox3.Controls.Add(this.tb_imienazwisko);
            this.groupBox3.Location = new System.Drawing.Point(1144, 347);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(319, 272);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dodaj użytkownika";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(68, 208);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 17);
            this.label9.TabIndex = 12;
            this.label9.Text = "hasło";
            // 
            // tb_haslo
            // 
            this.tb_haslo.Location = new System.Drawing.Point(123, 204);
            this.tb_haslo.Margin = new System.Windows.Forms.Padding(4);
            this.tb_haslo.Name = "tb_haslo";
            this.tb_haslo.Size = new System.Drawing.Size(185, 22);
            this.tb_haslo.TabIndex = 11;
            // 
            // btnDodajUzytkownika
            // 
            this.btnDodajUzytkownika.Location = new System.Drawing.Point(209, 236);
            this.btnDodajUzytkownika.Margin = new System.Windows.Forms.Padding(4);
            this.btnDodajUzytkownika.Name = "btnDodajUzytkownika";
            this.btnDodajUzytkownika.Size = new System.Drawing.Size(100, 28);
            this.btnDodajUzytkownika.TabIndex = 10;
            this.btnDodajUzytkownika.Text = "Dodaj";
            this.btnDodajUzytkownika.UseVisualStyleBackColor = true;
            this.btnDodajUzytkownika.Click += new System.EventHandler(this.button3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(57, 158);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 17);
            this.label7.TabIndex = 9;
            this.label7.Text = "semestr";
            // 
            // tb_semestr
            // 
            this.tb_semestr.Location = new System.Drawing.Point(124, 154);
            this.tb_semestr.Margin = new System.Windows.Forms.Padding(4);
            this.tb_semestr.Name = "tb_semestr";
            this.tb_semestr.Size = new System.Drawing.Size(185, 22);
            this.tb_semestr.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 126);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = "kierunek";
            // 
            // tb_kierunek
            // 
            this.tb_kierunek.Location = new System.Drawing.Point(123, 122);
            this.tb_kierunek.Margin = new System.Windows.Forms.Padding(4);
            this.tb_kierunek.Name = "tb_kierunek";
            this.tb_kierunek.Size = new System.Drawing.Size(185, 22);
            this.tb_kierunek.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(69, 94);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "grupa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 62);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "nr. indeksu";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "imie i nazwisko";
            // 
            // tb_grupa
            // 
            this.tb_grupa.Location = new System.Drawing.Point(123, 90);
            this.tb_grupa.Margin = new System.Windows.Forms.Padding(4);
            this.tb_grupa.Name = "tb_grupa";
            this.tb_grupa.Size = new System.Drawing.Size(185, 22);
            this.tb_grupa.TabIndex = 2;
            // 
            // tb_index
            // 
            this.tb_index.Location = new System.Drawing.Point(123, 58);
            this.tb_index.Margin = new System.Windows.Forms.Padding(4);
            this.tb_index.Name = "tb_index";
            this.tb_index.Size = new System.Drawing.Size(185, 22);
            this.tb_index.TabIndex = 1;
            // 
            // tb_imienazwisko
            // 
            this.tb_imienazwisko.Location = new System.Drawing.Point(123, 26);
            this.tb_imienazwisko.Margin = new System.Windows.Forms.Padding(4);
            this.tb_imienazwisko.Name = "tb_imienazwisko";
            this.tb_imienazwisko.Size = new System.Drawing.Size(185, 22);
            this.tb_imienazwisko.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnBlokujURL);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.tb_www);
            this.groupBox4.Location = new System.Drawing.Point(1144, 626);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(317, 97);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Black list";
            // 
            // btnBlokujURL
            // 
            this.btnBlokujURL.Location = new System.Drawing.Point(209, 55);
            this.btnBlokujURL.Margin = new System.Windows.Forms.Padding(4);
            this.btnBlokujURL.Name = "btnBlokujURL";
            this.btnBlokujURL.Size = new System.Drawing.Size(100, 28);
            this.btnBlokujURL.TabIndex = 11;
            this.btnBlokujURL.Text = "Blokuj";
            this.btnBlokujURL.UseVisualStyleBackColor = true;
            this.btnBlokujURL.Click += new System.EventHandler(this.button4_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(31, 27);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "strona www";
            // 
            // tb_www
            // 
            this.tb_www.Location = new System.Drawing.Point(123, 23);
            this.tb_www.Margin = new System.Windows.Forms.Padding(4);
            this.tb_www.Name = "tb_www";
            this.tb_www.Size = new System.Drawing.Size(185, 22);
            this.tb_www.TabIndex = 11;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Location = new System.Drawing.Point(16, 33);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(1105, 548);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Podgląd";
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(16, 583);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(1105, 240);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Podgląd innych użytkowników";
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // listBoxProcesy
            // 
            this.listBoxProcesy.FormattingEnabled = true;
            this.listBoxProcesy.ItemHeight = 16;
            this.listBoxProcesy.Location = new System.Drawing.Point(1484, 67);
            this.listBoxProcesy.Name = "listBoxProcesy";
            this.listBoxProcesy.Size = new System.Drawing.Size(191, 580);
            this.listBoxProcesy.TabIndex = 12;
            this.listBoxProcesy.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // btnWyswietlProcesy
            // 
            this.btnWyswietlProcesy.Location = new System.Drawing.Point(1484, 33);
            this.btnWyswietlProcesy.Name = "btnWyswietlProcesy";
            this.btnWyswietlProcesy.Size = new System.Drawing.Size(191, 28);
            this.btnWyswietlProcesy.TabIndex = 13;
            this.btnWyswietlProcesy.Text = "Wyswietl Procesy";
            this.btnWyswietlProcesy.UseVisualStyleBackColor = true;
            this.btnWyswietlProcesy.Click += new System.EventHandler(this.button5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1674, 837);
            this.Controls.Add(this.btnWyswietlProcesy);
            this.Controls.Add(this.listBoxProcesy);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBoxKlienci;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbIPServera;
        private System.Windows.Forms.Button btnPodgladPulpitu;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zapiszZrzutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem koniecToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.Windows.Forms.Timer timer1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnDodajUzytkownika;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_semestr;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_kierunek;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_grupa;
        private System.Windows.Forms.TextBox tb_index;
        private System.Windows.Forms.TextBox tb_imienazwisko;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnBlokujURL;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_www;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_haslo;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.ListBox listBoxProcesy;
        private System.Windows.Forms.Button btnWyswietlProcesy;
    }
}

